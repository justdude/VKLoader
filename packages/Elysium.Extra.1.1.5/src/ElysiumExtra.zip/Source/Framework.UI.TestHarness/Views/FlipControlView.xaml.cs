﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for FlipControlView.xaml
    /// </summary>
    public partial class FlipControlView
    {
        public FlipControlView()
        {
            InitializeComponent();
        }
    }
}
