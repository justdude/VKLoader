﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for ScrollView.xaml
    /// </summary>
    public partial class ScrollView
    {
        public ScrollView()
        {
            InitializeComponent();
        }
    }
}
