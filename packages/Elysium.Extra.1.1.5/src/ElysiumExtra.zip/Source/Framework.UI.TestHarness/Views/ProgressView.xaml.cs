﻿namespace Framework.UI.TestHarness.Views
{
    /// <summary>
    /// Interaction logic for ProgressView.xaml
    /// </summary>
    public partial class ProgressView
    {
        public ProgressView()
        {
            InitializeComponent();
        }
    }
}
