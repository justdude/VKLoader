﻿namespace Framework.UI.TestHarness
{
    /// <summary>
    /// Interaction logic for Application XAML
    /// </summary>
    public partial class App
    {
    }
}
