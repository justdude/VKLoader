﻿namespace Framework.UI.Controls
{
    using System.Windows.Controls;

    public sealed class MessageDialogButton : Button
    {
    }
}
