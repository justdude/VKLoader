﻿namespace Framework.UI.Controls
{
    /// <summary>
    /// The wizard collection animation.
    /// </summary>
    public enum WizardCollectionAnimation
    {
        Random,
        Sequential
    }
}
